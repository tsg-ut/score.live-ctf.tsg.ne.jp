// clang -fsanitize=safe-stack -o chal chal.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define BUFSIZE 0x20
#define CHECK(_res) if (!(_res)) exit(0);

struct options {
    char buf[BUFSIZE];
    char *options[2];
};

enum {
    EDIT,
    SHOW,
    OTHER,
};

struct options get_input() {
    struct options res;
    printf("option1 > ");
    CHECK(fgets(res.buf, BUFSIZE, stdin));
    res.options[0] = res.buf;
    int len1 = strlen(res.buf);
    res.options[1] = res.buf + len1 + 1;
    printf("option2 > ");
    int len2 = BUFSIZE - 1 - len1;
    if (len2 > 0) CHECK(fgets(res.options[1], len2, stdin));
    return res;
}

void edit_option(struct options *options) {
    unsigned int idx;
    char buf[BUFSIZE];
    printf("index > ");
    scanf("%d%*c", &idx);
    if (idx >= 2) {
        printf("index out of range\n");
        return;
    }
    printf("new content > ");
    CHECK(fgets(buf, BUFSIZE, stdin));
    strncpy(options->options[idx], buf, strlen(options->options[idx]));
}

int wait_for_input() {
    printf("input \"edit\" or \"show\"...");
    char buf[8];
    scanf("%7s%*c", buf);
    if (strcmp(buf, "edit") == 0) return EDIT;
    else if (strcmp(buf, "show") == 0) return SHOW;
    return OTHER;
}

int main() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    srand(time(0));
    printf("Welcome to uranai2\n");
    while (1) {
        struct options options = get_input();
        while (1) {
            int res = wait_for_input();
            if (res == EDIT) edit_option(&options);
            else if (res == SHOW) break;
        }
        int res = rand() % 2;
        printf("result: %s\n", options.options[res]);
    }
}
