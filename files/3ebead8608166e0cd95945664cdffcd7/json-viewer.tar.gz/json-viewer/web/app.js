const express = require('express');
const session = require('express-session');
const createDOMPurify = require('dompurify');
const { JSDOM } = require('jsdom');
const { randomBytes } = require("node:crypto");

const window = new JSDOM('').window;
const DOMPurify = createDOMPurify(window);

const app = express();
app.use(express.urlencoded({ extended: false }));

app.use(session({
    secret: randomBytes(32).toString("hex"),
    cookie: { secure: false }
}));

app.use((_req, res, next) => {
    res.setHeader('Content-Security-Policy', "default-src 'none'; script-src 'unsafe-inline';");
    next();
});

app.get("/", (req, res) => {
    const params = req.query;

    params["secret"] = req.session.secret || "secret is not set";

    for (const key in params) {
        const escapechars = ["\\", "%", "&"]; // js, url, html escape chars
        if (typeof params[key] !== "string" || escapechars.some(char => key.includes(char) || params[key].includes(char))) {
            delete params[key];
        }
    }

    const sanitized = JSON.parse(DOMPurify.sanitize(JSON.stringify(params)));

    if (/TSGLIVE\{.+\}/.test(sanitized.secret)) {
        sanitized.secret = "TSGLIVE{*** REDACTED ***}";
    }

    res.send(`
        <h1>JSON Viewer</h1>
        <pre>${JSON.stringify(sanitized)}</pre>

        <button onclick="location.href='/?name=guest'"> check sample JSON </button>

        <form method="POST" action="/secret">
            <label for="secret">Set Secret:</label>
            <input type="text" id="secret" name="secret">
            <button id="submit" type="submit">Submit</button>
        </form>
    `);
});


app.post("/secret", (req, res) => {
    req.session.secret = req.body.secret;
    res.redirect("/");
});

// Error handling
app.use((err, _req, res, _next) => {
    console.error(err.stack);
    res.status(500).send('Something went wrong');
});

app.listen(3000, () => {
    console.log('Server listening on port 3000');
});