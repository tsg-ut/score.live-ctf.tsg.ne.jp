import json
import os
import sys
from math import gcd

from Crypto.Random.random import randrange
from Crypto.Util.number import getPrime


def det(A):
    return A[0][0] * A[1][1] - A[0][1] * A[1][0]


def mul(A, B, N):
    return [[sum(A[i][k] * B[k][j] for k in range(2)) % N
             for j in range(2)] for i in range(2)]


def inv(A, N):
    a, b = A[0]
    c, d = A[1]
    u = pow(det(A), -1, N)
    return [[d * u % N, -b * u % N], [-c * u % N, a * u % N]]


def matpow(A, exponent, N):
    result = [[1, 0], [0, 1]]
    while exponent:
        if exponent & 1:
            result = mul(result, A, N)
        A = mul(A, A, N)
        exponent >>= 1
    return result


def main():
    if "FLAG" not in os.environ:
        raise SystemExit("FLAG must be set")
    m = int.from_bytes(os.environ["FLAG"].encode("utf-8"), "big")
    e = 17
    while True:
        p, q = getPrime(1024), getPrime(1024)
        if p != q and gcd(e, (p - 1) * (q - 1)) == 1:
            break
    N = p * q
    if not (0 < m < N - 1 and m**e > N):
        raise SystemExit("FLAG must satisfy 0 < m < N-1, m^17 > N")
    while True:
        P = [[randrange(N) for _ in range(2)] for _ in range(2)]
        if gcd(det(P), N) == 1:
            break
    M = mul(mul(P, [[m, 0], [0, m + 1]], N), inv(P, N), N)
    C = matpow(M, e, N)
    json.dump({"N": N, "e": e, "C": C}, sys.stdout, indent=2)
    print()


if __name__ == "__main__":
    main()
