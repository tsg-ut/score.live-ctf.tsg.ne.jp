import json

with open("output.json") as f:
    data = json.load(f)
N, e, C = data["N"], data["e"], data["C"]

# solve the problem here!
