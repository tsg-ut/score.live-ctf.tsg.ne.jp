code = input("jail> ")
assert all(
    c not in code for c in set(__import__("string").punctuation) - {".", "_", "{", "}"}
), "Prohibited letter detected!"
eval(code, {"__builtins__": {}}, {"system": __import__("os").system})
